
MRUnit is a unit test driver for MapReduce programs for use with JUnit. See the overview
in the Javadoc for more details.
